#ifndef RECORD_H
#define RECORD_H
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <deque>

class record {
	std::deque<double>scores; //storing scores using a deque.
public:
	//sets up an empty record.
	record();

	//sets up a record with one score.
	record(double score); 

	//records a new score for the player. These scores are always non-negative.
	void add_score(double score); 

	//returns the best score ever added to the record. If none, then its set to zero.
	double best_score() const; 

	//returns the average of all the scores added to the record. If none, its set to zero.
	double overall_average() const; 

	//returns the average of the last 10 scores added to the record.If none, its set to zero.
	double recent_average() const; 

	//returns whether fewer than 10 scores have been recorded.
	bool novice() const; 
};
#endif