#ifndef TABLE_H
#define TABLE_H
#include "record.h"
#include <string>
#include <map>
#include <vector>

class table {
	//used for storing scores.
	std::map<std::string, record> playerRecords;
public:
	//adds a new score for the given player.
	void add_score(const std::string &name, double score);

	//returns the total number of players that a score has been recorded for.
	int num_players() const;

	//prints the name of the players with the highest recent average score, in order.
	std::vector<std::string> print_best_recent(int n) const;

	//returns the average of the best scores of all players.
	double average_best() const;

	//returns the name of the player with the highest overall average
	std::string best_overall() const;

	//returns the number of novice players.
	int novice_count() const;
};
#endif