#include "table.h"
#include <string>
#include <vector>
#include <map>

using namespace std;


void table::add_score(const string & name, double score)
{
	//adds a new record and adds a score to the record.
	playerRecords[name].add_score(score);
}

int table::num_players() const
{
	//returns the number of records stored
	return playerRecords.size();
}

//the binary predicate for print best recent
bool compare_recent(const pair<string, record> &p1, const pair <string, record> &p2)
{
	//is true if p1's average is larger than p2's.
	return p1.second.recent_average() > p2.second.recent_average();
}
vector<string> table::print_best_recent(int n) const
{
	vector<string> v;
	//the vector stores names and scores
	vector<pair<string, record>> pairs;
	for (map<string, record>::const_iterator p = playerRecords.cbegin();
		p != playerRecords.cend(); ++p) {
		pairs.push_back(*p);
	}
	//sorts the pairs in ascending order based on the score
	sort(pairs.begin(), pairs.end(), compare_recent);
	for (int i = 0; i < n && i < pairs.size(); ++i) {
		v.push_back(pairs[i].first);
	}
	//returns the best recent players
	return v;
}

double table::average_best() const
{
	//if there are no scores, then return 0.
	if (playerRecords.size() == 0) { return 0; }

	//sum of the sum of scores variable, as type double(score could be decimal place)
	double sumOfScores = 0;
	//instantiation of the numberOfScores.
	int numOfScores = 0;

	for (map<string, record>::const_iterator p =
		playerRecords.cbegin(); p != playerRecords.cend(); ++p) {

		sumOfScores += p->second.best_score();
		//increments the counter for numOfScores
		++numOfScores;
	}
	//calculation used for average
	return sumOfScores / numOfScores;
}

string table::best_overall() const
{
	//i used a map here,pairing the names and the player's score to store.
	pair<string, record> bestPair;

	for (map<string, record>::const_iterator p =
		playerRecords.cbegin(); p != playerRecords.cend(); ++p) {

		//is true if our new average score is greater than the current average
		if (bestPair.second.overall_average() < p->second.overall_average()) {
			bestPair = *p;
		}
	}
	//returns the player with the highest average score
	return bestPair.first;
}


//predicate used for novice count below
bool novicePredicate(pair<string, record> p)
{
	return p.second.novice();
}
int table::novice_count() const
{
	//counts the number of novice scores that are found in the map.
	return count_if(playerRecords.cbegin(), playerRecords.cend(), novicePredicate);
}
