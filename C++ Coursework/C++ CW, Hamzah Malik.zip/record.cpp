#include "record.h"
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <deque>

using namespace std;

//Sets up an empty record
record::record()
{

}

record::record(double score)
{
	//adds the current score to the score list.
	scores.push_back(score);
}

void record::add_score(double score)
{
	//adds the current score to the score list.
	scores.push_back(score);
}

double record::best_score() const
{
	//Initialises a value named bestScore set to 0.
	double bestScore = 0;
	//returns the max value that is calculated when adding scores, using a deque.
	for (deque<double>::const_iterator s = scores.cbegin(); s != scores.cend(); ++s) {

		if (bestScore < *s) {
			bestScore = *s;
		}
	}
	return bestScore;
}

double record::overall_average() const
{
	//if the size of scores = 0, then return 0.
	if (scores.size() == 0) return 0.0;

	//initalise sum as double.
	double sum = 0.0;

	for (deque <double> ::const_iterator s = scores.cbegin(); s != scores.cend(); ++s) {
		sum = sum + *s;
	}

	//returns the sum divided by the number of the scores.
	return sum / scores.size();
}

double record::recent_average() const
{
	//If no scores exist then return 0
	if (scores.size() == 0)
		return 0;

	//initialise sum
	double sum = 0;
	//size cannot be negative
	unsigned size;

	//checks if the number of scores is greater or equal to 10
	if (scores.size() >= 10) size = 10;
	//otherwise size is equal to number of scores
	else size = scores.size();
	typedef deque<double>::const_iterator iter;
	for (iter i = scores.cend() - size; i != scores.cend(); ++i) {
		sum += *i;
	}
	//returns the sum divided by the size
	return sum / size;
}

bool record::novice() const
{
	//amounts to true if number of scores are less than 10.
	return scores.size() < 10;
}

